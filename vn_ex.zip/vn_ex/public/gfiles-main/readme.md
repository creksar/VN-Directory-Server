# Game files

Bundles some HTML5 games, flash games through ruffle (swfs are [here](https://github.com/BinBashBanana/gstore)), and [webretro](https://github.com/BinBashBanana/webretro).

Indexed using the python script included.

---

This was forked from [LQ16's repository](https://github.com/LQ16/gfiles), which is long deleted.